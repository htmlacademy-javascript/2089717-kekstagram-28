// function outer() {
//   let counter = 0;
//   function inner () {
//     counter++;
//     console.log('counter = ', counter);
//   }
//   return inner;
// }

// const inner = outer();
// inner()
// inner()



// const multiply = function (a) {
//   const multiplyInner = function (b) {
//     return a * b
//   }
//   return multiplyInner
// }

// const six = multiply(2)(3)
// console.log(six)




